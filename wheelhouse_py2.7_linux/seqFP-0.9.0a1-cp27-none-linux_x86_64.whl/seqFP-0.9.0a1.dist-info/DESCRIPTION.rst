A fingerprint based sequences similarity tool
=============================================

The program works using an approach similar to that of the daylight fingerprint
but applied to the subsets of short words that can be recovered from a 
sequence.

----

The package provides libraries and applications to generate the fingerprints 
and perform a screening against a reference. The fingerprints are stored in the
HDF5 format. At the moment the program accept only sequence in fasta format, 
but can be further extended to read other formats.

---------------------------

Prebuilt wheels are available at https://github.com/giorgiomaccari/seqFP-wheels


